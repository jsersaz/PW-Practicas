Para ejecutar este proyecto, puede:
	1. Abrir eclipse y ejecutar el mainprincipal en la opción de ejecutar programa
	2. Ejecutar el JAR que se encuentra en el directorio raíz desde terminal con <java -jar GM2_i22sesaj>