package es.uco.pw.data.dao;

import java.io.BufferedReader;


import es.uco.pw.business.jugador.JugadorDTO;
import es.uco.pw.business.reserva.BonoDTO;
import es.uco.pw.business.reserva.gestordereservas;
import es.uco.pw.data.common.DBConnection;
import java.sql.*;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.PreparedStatement;

import java.time.LocalDate;

/**
 * Clase que gestiona los usuarios registrados en el sistema.
 * Permite agregar, modificar, listar y respaldar jugadores.
 */
public class gestordeusuariosDAO {

	private static gestordeusuariosDAO gestor;
    private Properties properties;
    private Connection connection;

    
    /**
     * Método para obtener la instancia única del gestor de reservas.
     *
     * @return la instancia del gestor
     */
    public static gestordeusuariosDAO getGestor() {
        if (gestor == null) {
            gestor = new gestordeusuariosDAO();
        }
        return gestor;
    }
    
    
    /**
     * Constructor de gestordeusuariosDAO.
     * Inicializa las propiedades de la clase y carga la configuración SQL desde un archivo de propiedades.
     */
    public gestordeusuariosDAO()
    {
    	properties=new Properties();
        try (BufferedReader lector = new BufferedReader(new FileReader("sql.properties"))) {
            properties.load(lector);
        }  catch (FileNotFoundException e) {
        	e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Añade un nuevo jugador al sistema si no está registrado previamente.
     * 
     * @param p El jugador a añadir.
     * @return true si el jugador se añade con éxito; false si ya está registrado.
     */
    public boolean addJugador(JugadorDTO p) 
    {
    	DBConnection coneccion=new DBConnection();
    	connection= coneccion.getConnection();
    	try {
    		String sql = properties.getProperty("addJugador");
            System.out.println("Consulta SQL: " + sql);
            
            System.out.println(p.getDni()+ " " + p.getNombre()+ " " + p.getApellidos() + " " + p.getFechaNacimiento().toString() + " " + p.getFechaInscripcion().toString() + " " + p.getEmail());
            
    		//PreparedStatement preparedstatement = connection.prepareStatement(properties.getProperty("addJugador"));
            PreparedStatement preparedstatement = connection.prepareStatement(sql);
    		//prep.setInt(1, 1);
    		//prep.setInt(2, 2);
    		
    		preparedstatement.setString(1, p.getDni());
    		preparedstatement.setString(2, p.getNombre());
    		preparedstatement.setString(3, p.getApellidos());
    		preparedstatement.setDate(4, Date.valueOf(p.getFechaNacimiento()));
    		preparedstatement.setDate(5, Date.valueOf(p.getFechaInscripcion()));
    		preparedstatement.setString(6, p.getEmail());
    		int status = preparedstatement.executeUpdate();
    		System.out.println(status);
	
    		
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	coneccion.closeConnection();
		return true;
    }

    /**
     * Modifica la información de un jugador en el sistema.
     * 
     * @param nombrenuevo El nuevo nombre del jugador.
     * @param apellidosnuevos Los nuevos apellidos del jugador.
     * @param nuevaFechaNacimientoDate La nueva fecha de nacimiento del jugador.
     * @param nuevoEmail El nuevo correo electrónico del jugador.
     * @param DNIBuscar El DNI del jugador a buscar para modificar.
     * @return true si se modifica la información correctamente; false si no se encuentra el jugador.
     */
    public boolean modificarJugador(String nombrenuevo, String apellidosnuevos, LocalDate nuevaFechaNacimientoDate, String nuevoEmail, String DNIBuscar) {
    	DBConnection coneccion=new DBConnection();
    	connection= coneccion.getConnection();
    	try {
    		String sql = properties.getProperty("modificar");
            System.out.println("Consulta SQL: " + sql);
            
            //System.out.println(p.getDni()+ " " + p.getNombre()+ " " + p.getApellidos() + " " + p.getFechaNacimiento().toString() + " " + p.getFechaInscripcion().toString() + " " + p.getEmail());
            
    		//PreparedStatement preparedstatement = connection.prepareStatement(properties.getProperty("addJugador"));
            PreparedStatement preparedstatement = connection.prepareStatement(sql);
    		//preparedstatement.setInt(1, 1);
    		//prep.setInt(2, 2);
            preparedstatement.setString(1, nombrenuevo);
            preparedstatement.setString(2, apellidosnuevos);
            preparedstatement.setDate(3, Date.valueOf(nuevaFechaNacimientoDate));
            preparedstatement.setString(4, nuevoEmail);
            preparedstatement.setString(5, DNIBuscar);
            
            int rowsAffected = preparedstatement.executeUpdate();
            System.out.println("Filas actualizadas: " + rowsAffected);

            // Cerrar PreparedStatement
            preparedstatement.close();

            // Si se ha actualizado al menos una fila, el cambio fue exitoso
            return rowsAffected > 0;
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	coneccion.closeConnection();
		return true;
    }
    

    /**
     * Imprime en la consola la lista de jugadores actualmente registrados.
     */
    public void print() {
    	DBConnection coneccion=new DBConnection();
    	connection= coneccion.getConnection();
    	try {
    		String sql = properties.getProperty("listar");
            System.out.println("Consulta SQL: " + sql);
            
            PreparedStatement preparedstatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedstatement.executeQuery();

            // Iterar a través de los resultados e imprimir cada jugador
            while (resultSet.next()) {
                String dni = resultSet.getString("DNI");
                String nombre = resultSet.getString("nombre");
                String apellidos = resultSet.getString("apellidos");
                Date fechaNacimiento = resultSet.getDate("fecha_nacimiento");
                Date fechaInscripcion = resultSet.getDate("fecha_inscripcion");
                String email = resultSet.getString("email");

                // Imprimir los detalles del jugador
                System.out.println("DNI: " + dni + ", Nombre: " + nombre + ", Apellidos: " + apellidos + 
                                   ", Fecha de Nacimiento: " + fechaNacimiento + 
                                   ", Fecha de Inscripción: " + fechaInscripcion + ", Email: " + email);
            }

            // Cerrar ResultSet y PreparedStatement
            resultSet.close();
            preparedstatement.close();
    	}
    	catch(SQLException e)
    	{
    		e.printStackTrace();
    	}
    	coneccion.closeConnection();
    }
}