package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.business.reserva.BonoDTO;
import es.uco.pw.data.common.DBConnection;


/**
 * Clase encargada de interactuar con la base de datos para gestionar los bonos.
 * Esta clase contiene métodos para insertar, obtener y actualizar bonos.
 */
public class BonoDAO {
	private Connection con;
	private Properties prop;
	
	
	/**
     * Constructor que carga las propiedades de configuración necesarias para
     * interactuar con la base de datos.
     */
	public BonoDAO()
	{
		prop= new Properties(); 
		try (FileInputStream input = new FileInputStream("sql.properties")) {
			prop.load(input);
		} catch (IOException e) {e.printStackTrace();}	   
	}
	
	
	/**
     * Obtiene los detalles de un bono desde la base de datos utilizando su ID.
     * 
     * @param id_bono El identificador del bono a obtener.
     * @return Un mapa con los detalles del bono, como el número de sesión, fecha
     *         de caducidad, fecha de creación y tipo de pista.
     */
	public Map<String, Object> obtenerBono(String id_bono){
		Map<String, Object> result = null;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("getBono");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id_bono);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				result = new HashMap<>();
				result.put("ID_BONO", id_bono);
				result.put("numero_sesión", rs.getString("numero_sesión"));
				result.put("fecha_caducidad", rs.getString("fecha_caducidad"));
				result.put("fecha_creación", rs.getString("fecha_creación"));
				result.put("tipo_pista", rs.getString("tipo_pista"));
			}
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return result;
	}
	
	
	/**
     * Inserta un nuevo bono en la base de datos.
     * 
     * @param bono El objeto BonoDTO que contiene los detalles del bono a insertar.
     * @return El número de filas afectadas en la base de datos.
     */
	public int insertarBono(BonoDTO bono) {
		int status = 0;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("addBono");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, bono.getIdBono());
			ps.setInt(2, bono.getNumeroSesion());
			ps.setDate(3, Date.valueOf(bono.getFechaCaducidad()));
			ps.setDate(4, Date.valueOf(bono.getFechaCreacion()));
			ps.setString(5, bono.getTipoPista().name());
			
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return status;
	}
	
	
	/**
     * Actualiza el número de sesiones de un bono en la base de datos.
     * 
     * @param bono El objeto BonoDTO con el nuevo número de sesiones.
     * @return El número de filas afectadas en la base de datos.
     */
	public int actualizarBono(BonoDTO bono) {
		int status = 0;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("updateBono");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setInt(1, bono.getNumeroSesion());
			ps.setString(2, bono.getIdBono());
			
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return status;
	}
}
