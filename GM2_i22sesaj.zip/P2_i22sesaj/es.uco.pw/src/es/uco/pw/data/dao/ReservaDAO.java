package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.business.jugador.JugadorDTO;
import es.uco.pw.business.pista.PistaDTO;
import es.uco.pw.business.reserva.BonoDTO;
import es.uco.pw.business.reserva.ReservaAdultosDTO;
import es.uco.pw.business.reserva.ReservaBonoDTO;
import es.uco.pw.business.reserva.ReservaDTO;
import es.uco.pw.business.reserva.ReservaFactoryDTO;
import es.uco.pw.business.reserva.ReservaFamiliarDTO;
import es.uco.pw.business.reserva.ReservaIndividualDTO;
import es.uco.pw.business.reserva.ReservaInfantilDTO;
import es.uco.pw.data.common.DBConnection;


/**
 * Clase encargada de interactuar con la base de datos para gestionar las reservas.
 * Contiene métodos para insertar, obtener y borrar reservas de distintos tipos
 * (Infantil, Familiar, Adultos) en la base de datos.
 */
public class ReservaDAO {	
	private Connection con;
	private Properties prop;
	
	
	/**
     * Constructor de la clase. Carga las propiedades necesarias para ejecutar
     * las consultas SQL en la base de datos.
     */
	public ReservaDAO()
	{
  		//CONSTRUCTOR, TIENE LAS LLAMADAS EN SQL  QUE TENEMOS QUE HACER A LA BASE DE DATOS
       prop= new Properties(); 
        try (FileInputStream input = new FileInputStream("sql.properties")) {
            prop.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
		   
	}
	
	
	/**
     * Obtiene una reserva de la base de datos mediante su identificador.
     * 
     * @param id_reserva El identificador de la reserva a obtener.
     * @return Un mapa con los datos de la reserva, o null si no se encuentra.
     */
	public Map<String, Object> obtenerReserva(String id_reserva){
		Map<String, Object> result = null;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("getReserva");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id_reserva);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				result = new HashMap<>();
				result.put("ID_RESERVA", id_reserva);
				result.put("id_usuario", rs.getString("id_usuario"));
				result.put("fecha", rs.getString("fecha"));
				result.put("duración", rs.getString("duración"));
				result.put("id_pista", rs.getString("id_pista"));
				result.put("precio", rs.getString("precio"));
				result.put("descuento", rs.getString("descuento"));
				result.put("Id_bono", rs.getString("Id_bono"));
				result.put("numero_sesion", rs.getString("numero_sesion"));
			}
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return result;
	}
	
	
	/**
     * Inserta una reserva infantil en la base de datos.
     * 
     * @param reservaInfantil El objeto ReservaInfantilDTO que contiene los datos de la reserva.
     * @return El número de registros insertados (0 si hay un error).
     */
	public int insertarReservaInfantil(ReservaInfantilDTO reservaInfantil)
	{
		int status = 0;
		DBConnection connection = new DBConnection();
		String sql;
		 
		try {
			sql = prop.getProperty("addReserva");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			 
			ps.setString(1, reservaInfantil.getIdReserva());
			ps.setString(2, reservaInfantil.getIdUsuario());
			ps.setDate(3, Date.valueOf(reservaInfantil.getFecha()));
			ps.setInt(4, reservaInfantil.getDuracion());
			ps.setString(5, reservaInfantil.getIdPista());
			ps.setFloat(6, reservaInfantil.getPrecio());
			ps.setFloat(7, reservaInfantil.getDescuento());
			ps.setString(8, reservaInfantil.getIdBono());
			ps.setInt(9, reservaInfantil.getNumeroSesion());
			 
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		 
		try {
			sql = prop.getProperty("addInfantil");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, reservaInfantil.getIdReserva());
			ps.setInt(2, reservaInfantil.getNumeroNinos());
			 
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		 
		connection.closeConnection();
		return status;
	}
	 

	/**
     * Inserta una reserva familiar en la base de datos.
     * 
     * @param reservaFamiliar El objeto ReservaFamiliarDTO que contiene los datos de la reserva.
     * @return El número de registros insertados (0 si hay un error).
     */
	 public int insertarReservaFamiliar(ReservaFamiliarDTO reservaFamiliar) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("addReserva");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reservaFamiliar.getIdReserva());
			 ps.setString(2, reservaFamiliar.getIdUsuario());
			 ps.setDate(3, Date.valueOf(reservaFamiliar.getFecha()));
			 ps.setInt(4, reservaFamiliar.getDuracion());
			 ps.setString(5, reservaFamiliar.getIdPista());
			 ps.setFloat(6, reservaFamiliar.getPrecio());
			 ps.setFloat(7, reservaFamiliar.getDescuento());
			 ps.setString(8, reservaFamiliar.getIdBono());
			 ps.setInt(9, reservaFamiliar.getNumeroSesion());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 try {
			 sql = prop.getProperty("addFamiliar");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reservaFamiliar.getIdReserva());
			 ps.setInt(2, reservaFamiliar.getNumeroAdultos());
			 ps.setInt(3, reservaFamiliar.getNumeroNinos());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Inserta una reserva de adultos en la base de datos.
	     * 
	     * @param reservaAdultos El objeto ReservaAdultosDTO que contiene los datos de la reserva.
	     * @return El número de registros insertados (0 si hay un error).
	     */
	 public int insertarReservaAdultos(ReservaAdultosDTO reservaAdultos) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("addReserva");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reservaAdultos.getIdReserva());
			 ps.setString(2, reservaAdultos.getIdUsuario());
			 ps.setDate(3, Date.valueOf(reservaAdultos.getFecha()));
			 ps.setInt(4, reservaAdultos.getDuracion());
			 ps.setString(5, reservaAdultos.getIdPista());
			 ps.setFloat(6, reservaAdultos.getPrecio());
			 ps.setFloat(7, reservaAdultos.getDescuento());
			 ps.setString(8, reservaAdultos.getIdBono());
			 ps.setInt(9, reservaAdultos.getNumeroSesion());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 try {
			 sql = prop.getProperty("addAdulto");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reservaAdultos.getIdReserva());
			 ps.setInt(2, reservaAdultos.getNumeroParticipantes());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Borra una reserva de la base de datos.
	     * 
	     * @param reserva El objeto ReservaDTO que contiene los datos de la reserva a eliminar.
	     * @return El número de registros eliminados (0 si hay un error).
	     */
	 public int borrarReserva(ReservaDTO reserva) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("deleteReserva");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reserva.getIdReserva());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Borra una reserva infantil de la base de datos.
	     * 
	     * @param reserva El objeto ReservaDTO que contiene los datos de la reserva infantil a eliminar.
	     * @return El número de registros eliminados (0 si hay un error).
	     */
	 public int borrarInfantil(ReservaDTO reserva) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("deleteInfantil");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reserva.getIdReserva());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Borra una reserva familiar de la base de datos.
	     * 
	     * @param reserva El objeto ReservaDTO que contiene los datos de la reserva familiar a eliminar.
	     * @return El número de registros eliminados (0 si hay un error).
	     */
	 public int borrarFamiliar(ReservaDTO reserva) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("deleteFamiliar");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reserva.getIdReserva());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Borra una reserva de adultos de la base de datos.
	     * 
	     * @param reserva El objeto ReservaDTO que contiene los datos de la reserva de adultos a eliminar.
	     * @return El número de registros eliminados (0 si hay un error).
	     */
	 public int borrarAdulto(ReservaDTO reserva) {
		 int status = 0;
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("deleteAdulto");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ps.setString(1, reserva.getIdReserva());
			 
			 status = ps.executeUpdate();
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return status;
	 }
	 
	 
	 /**
	     * Obtiene el número de reservas futuras en la base de datos.
	     * 
	     * @return El número de reservas futuras.
	     */
	 public int reservasFuturas() {
		 DBConnection connection = new DBConnection();
		 String sql;
		 int numeroReservas = 0;
		 
		 try {
			 sql = prop.getProperty("reservasFuturas");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 
			 ResultSet rs = ps.executeQuery();
			 if(rs.next()) {
				 numeroReservas = rs.getInt("numero_reservas");
			 }
			 
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
		 return numeroReservas;
	 }
	 
	 
	 /**
	     * Muestra las reservas realizadas en un día específico para una pista dada.
	     * 
	     * @param fecha_r La fecha en la que se consultan las reservas.
	     * @param nombre_pista El nombre de la pista para la cual se consultan las reservas.
	     */
	 public void reservasDiaYPista(LocalDate fecha_r, String nombre_pista) {
		 DBConnection connection = new DBConnection();
		 String sql;
		 
		 try {
			 sql = prop.getProperty("reservasDiaYPista");
			 con = (Connection) connection.getConnection();
			 PreparedStatement ps = con.prepareStatement(sql);
			 ps.setDate(1, Date.valueOf(fecha_r));
			 ps.setString(2, nombre_pista);
			 
			 ResultSet rs = ps.executeQuery();
			 if(!rs.next()) {
				 System.out.println("No hay reservas para la fecha y pista seleccionadas.");
			 }
			 else {
				do {
					String ID_RESERVA = rs.getString("ID_RESERVA");
                    String id_usuario = rs.getString("id_usuario");
                    LocalDate fecha = rs.getDate("fecha").toLocalDate();
                    int duracion = rs.getInt("duración");
                    double precio = rs.getDouble("precio");
                    double descuento = rs.getDouble("descuento");
                    String Id_bono = rs.getString("Id_bono");
                    int numero_sesion = rs.getInt("numero_sesion");
                    
                    System.out.println("ID Reserva: '" + ID_RESERVA + "'");
                    System.out.println("ID Usuario: '" + id_usuario + "'");
                    System.out.println("Fecha: " + fecha);
                    System.out.println("Duración: " + duracion + " minutos");
                    System.out.println("Precio: " + precio + " EUR");
                    System.out.println("Descuento: " + descuento + " EUR");
                    System.out.println("ID Bono: '" + Id_bono + "'");
                    System.out.println("Número de sesión: " + numero_sesion);
                    System.out.println();
				} while(rs.next());
			 }
		 } catch(Exception e) {System.out.println(e);}
		 
		 connection.closeConnection();
	 }
}