package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.data.common.DBConnection;


/**
 * Clase encargada de interactuar con la base de datos para gestionar la información
 * de los jugadores.
 * Esta clase contiene métodos para obtener los detalles de un jugador basado en su DNI.
 */
public class JugadorDAO {
	private Connection con;
	private Properties prop;
	
	
	/**
     * Constructor que carga las propiedades de configuración necesarias para
     * interactuar con la base de datos.
     */
	public JugadorDAO()
	{
		prop= new Properties(); 
		try (FileInputStream input = new FileInputStream("sql.properties")) {
			prop.load(input);
		} catch (IOException e) {e.printStackTrace();}	   
	}
	
	
	/**
     * Obtiene los detalles de un jugador desde la base de datos utilizando su DNI.
     * 
     * @param dni El DNI del jugador a obtener.
     * @return Un mapa con los detalles del jugador, como nombre, apellidos, fecha de
     *         nacimiento, fecha de inscripción y email.
     */
	public Map<String, Object> obtenerJugador(String dni){
		Map<String, Object> result = null;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("getJugador");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dni);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				result = new HashMap<>();
				result.put("DNI", dni);
				result.put("nombre", rs.getString("nombre"));
				result.put("apellidos", rs.getString("apellidos"));
				result.put("fecha_nacimiento", rs.getString("fecha_nacimiento"));
				result.put("fecha_inscripcion", rs.getString("fecha_inscripcion"));
				result.put("email", rs.getString("email"));
			}
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return result;
	}
}
