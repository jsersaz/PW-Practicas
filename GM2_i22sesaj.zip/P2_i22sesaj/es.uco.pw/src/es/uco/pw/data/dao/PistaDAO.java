package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.data.common.DBConnection;
import es.uco.pw.business.material.Estado;
import es.uco.pw.business.material.MaterialDTO;
import es.uco.pw.business.material.Tipo;
import es.uco.pw.business.pista.PistaDTO;
import es.uco.pw.business.pista.tamanopista;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;


/**
 * Clase encargada de interactuar con la base de datos para gestionar la información
 * relacionada con las pistas.
 * Esta clase permite obtener los detalles de una pista a partir de su nombre.
 */
public class PistaDAO {
	private Connection con;
	private Properties prop;
	
	
	/**
     * Constructor que carga las propiedades de configuración necesarias para
     * interactuar con la base de datos.
     */
	public PistaDAO()
	{
		prop= new Properties(); 
		try (FileInputStream input = new FileInputStream("sql.properties")) {
			prop.load(input);
		} catch (IOException e) {e.printStackTrace();}	   
	}
	
	
	/**
     * Obtiene los detalles de una pista desde la base de datos utilizando su nombre.
     * 
     * @param nombre El nombre de la pista a obtener.
     * @return Un mapa con los detalles de la pista, como tipo (interior o exterior),
     *         estado, tamaño y el número máximo de jugadores.
     */
	public Map<String, Object> obtenerPista(String nombre){
		Map<String, Object> result = null;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("getPista");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nombre);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				result = new HashMap<>();
				result.put("NOMBRE_PISTA", nombre);
				result.put("tipo_interior", rs.getString("tipo_interior"));
				result.put("estado", rs.getString("estado"));
				result.put("tamaño", rs.getString("tamaño"));
				result.put("max_jugadores", rs.getString("max_jugadores"));
			}
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return result;
	}
	
	
    /**
     * Agrega una nueva pista a la base de datos.
     * Esta función toma un objeto PistaDTO, extrae los atributos de la pista y los inserta
     * en la base de datos a través de una sentencia SQL preparada.
     *
     * @param pistaNueva El objeto PistaDTO que contiene la información de la nueva pista.
     * @return true si la pista se ha agregado correctamente, false si ocurre algún error.
     */
    public boolean addPista(PistaDTO pistaNueva)
    {
    	DBConnection connection = new DBConnection();
		String sql;
        boolean Insertado = false;

        try {
        	sql = prop.getProperty("addPista");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, pistaNueva.getNombre());
			ps.setInt(2, pistaNueva.isEstado() ? 1 : 0);
			ps.setInt(3, pistaNueva.isTipoInterior() ? 1 : 0);
			ps.setString(4, pistaNueva.getTamano().name());
			ps.setInt(5, pistaNueva.getMaxJugadores());

            int status = ps.executeUpdate();
            Insertado = (status > 0);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        connection.closeConnection();
        return Insertado;
    }

    /**
     * Verifica si una pista con el nombre especificado ya existe en la base de datos.
     * Realiza una consulta SQL para comprobar si existe una pista con el nombre proporcionado.
     *
     * @param nombrePista El nombre de la pista que se desea verificar.
     * @return true si la pista existe en la base de datos, false en caso contrario.
     */
    public boolean nombrePistaExiste(String nombrePista)
    {
    	DBConnection connection = new DBConnection();
		String sql;
        boolean existe = false;

        try {
        	sql = prop.getProperty("PistaExiste");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			 
			ps.setString(1, nombrePista.trim());
            ResultSet resultSet = ps.executeQuery();
            
            if (resultSet.next()) {
                existe = resultSet.getInt(1) > 0;
            }
            
            resultSet.close();
            ps.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        
        connection.closeConnection();
        return existe;
    }
    
    /**
     * Busca una pista en la base de datos utilizando su identificador único (ID).
     * Realiza una consulta SQL para obtener la pista correspondiente al ID proporcionado.
     *
     * @param idPista El identificador de la pista que se desea obtener.
     * @return Un objeto PistaDTO con los detalles de la pista encontrada, o null si no se encuentra.
     */
    private PistaDTO buscarPistaPorId(int idPista)
    {
    	DBConnection connection = new DBConnection();
		String sql;
        PistaDTO pista = null;

        try {
        	sql = prop.getProperty("getPistaById");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			 
            ps.setInt(1, idPista);
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next())
            {
                pista = new PistaDTO();
                pista.setNombre(resultSet.getString("NOMBRE_PISTA"));
                pista.setEstado(resultSet.getString("estado").equalsIgnoreCase("disponible"));
                pista.setTipoInterior(resultSet.getString("tipo_interior").equalsIgnoreCase("true"));
                pista.setTamano(tamanopista.valueOf(resultSet.getString("tamaño").toUpperCase()));
                pista.setMaxJugadores(resultSet.getInt("max_jugadores"));
            }

            resultSet.close();
            ps.close();
            
        } catch (SQLException e)
        {
        	e.printStackTrace();
        }
        
        connection.closeConnection();
        return pista;
    }

    private <E extends Enum<E>> E getEnumValue(Class<E> enumClass, String value) {
        try {
            return Enum.valueOf(enumClass, value);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Obtiene todos los materiales de la base de datos.
     * Realiza una consulta SQL para recuperar todos los materiales y sus atributos. 
     * Los materiales son almacenados en una lista de objetos MaterialDTO.
     *
     * @return Una lista de objetos MaterialDTO que representan todos los materiales en la base de datos.
     */
    public ArrayList<MaterialDTO> cargarMaterialesBD()
    {
        ArrayList<MaterialDTO> materiales = new ArrayList<>();
        DBConnection connection = new DBConnection();
		String sql;

        try {
        	sql = prop.getProperty("getAllMateriales");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();

            while (resultSet.next()) {
                MaterialDTO material = new MaterialDTO();
                material.setIdentificador(resultSet.getInt("ID_MATERIAL"));
                material.setUso(resultSet.getBoolean("uso_exterior"));
                //material.setTipo(Tipo.valueOf(resultSet.getString("tipo").toLowerCase()));
                //material.setEstado(Estado.valueOf(resultSet.getString("estado").toLowerCase()));

                Tipo tipo = getEnumValue(Tipo.class, resultSet.getString("tipo").toLowerCase());
                if (tipo == null) {
                    continue;
                }
                material.setTipo(tipo);
                
                Estado estado = getEnumValue(Estado.class, resultSet.getString("estado").toLowerCase());
                if (estado == null) {
                    continue;
                }
                material.setEstado(estado);
                
                String pistaAsociada = resultSet.getString("pista_asociada");
                if (pistaAsociada != null && !pistaAsociada.isEmpty()) {
                    PistaDTO pista = buscarPistaPorId(Integer.parseInt(pistaAsociada));
                    if (pista != null) {
                        material.setPistaAsociada(pista);
                    }
                }
                materiales.add(material);
            }

            resultSet.close();
            ps.close();
        } catch (SQLException e)
        {
            e.printStackTrace();
        }
        
        connection.closeConnection();
        return materiales;
    }
    
    /**
     * Busca un material en la base de datos utilizando su identificador único (ID).
     * Realiza una consulta SQL para obtener los detalles del material con el ID especificado.
     *
     * @param id El identificador del material que se desea obtener.
     * @return Un objeto MaterialDTO con los detalles del material encontrado, o null si no se encuentra.
     */
    public MaterialDTO buscarMaterialPorId(int id)
    {
    	DBConnection connection = new DBConnection();
		String sql;
        MaterialDTO material = null;
    
        try {
        	sql = prop.getProperty("MaterialId");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet resultSet = ps.executeQuery();
    
            if (resultSet.next()) {
                material = new MaterialDTO();
                material.setIdentificador(resultSet.getInt("id"));
                material.setTipo(Tipo.valueOf(resultSet.getString("tipo")));
                material.setUso(resultSet.getBoolean("uso"));
                material.setEstado(Estado.valueOf(resultSet.getString("estado")));
            }
    
            resultSet.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        connection.closeConnection();    
        return material;
    }    

    /**
     * Lista los materiales disponibles cargados desde la base de datos.
     * Muestra una lista de los materiales junto con sus identificadores y tipos de uso (exterior o interior).
     */
    public void listarMateriales() {
        ArrayList<MaterialDTO> materiales = cargarMaterialesBD();

        if (materiales.isEmpty()) {
            System.out.println("No hay materiales disponibles.");
        } else {
            System.out.println("Materiales:");
            for (MaterialDTO material : materiales) {
                System.out.println("-> ID: " + material.getIdentificador() + ", Nombre: " + material.getTipo() + ", Tipo: " + (material.isUso() ? "exterior" : "interior"));
            }
        }
    }
    
    /**
     * Lista las pistas que no están disponibles en la base de datos.
     * Realiza una consulta SQL para obtener las pistas que no están disponibles y muestra sus detalles.
     */
    public void listarPistasNoDisponibles() {
    	DBConnection connection = new DBConnection();
		String sql;
        boolean pistasEncontradas = false;
        
        System.out.println("Pistas no disponibles:");
        try {
        	sql = prop.getProperty("PistaNoDisponible");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String nombrePista = rs.getString("NOMBRE_PISTA");
                String tamaño = rs.getString("tamaño");
                boolean tipoInterior = rs.getBoolean("tipo_interior");
                int maxjugadores = rs.getInt("max_jugadores");
                System.out.println("-> Nombre: " + nombrePista + ", Tamaño: " + tamaño + ", Interior: " + (tipoInterior ? "Sí" : "No")+ ", Max jugadores: " + maxjugadores);
                pistasEncontradas = true;
            }

            if (!pistasEncontradas) {
                System.out.println("No hay pistas no disponibles actualmente.");
            }

            rs.close();
            ps.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        
        connection.closeConnection();
    }
    
    /**
     * Busca pistas libres basándose en el número de jugadores y si la pista es interior o exterior.
     * Realiza una consulta SQL para encontrar las pistas que cumplan con los criterios proporcionados.
     *
     * @param numJugadores El número de jugadores que deben caber en la pista.
     * @param esInterior true si se busca una pista interior, false si es exterior.
     */
    public void buscarPistasLibres(int numJugadores, boolean esInterior) {
    	DBConnection connection = new DBConnection();
		String sql;
		boolean pistasEncontradas = false;
		
		System.out.println("Pistas libres para " + numJugadores + " jugadores (" + (esInterior ? "interior" : "exterior") + "):");

		try {
			sql = prop.getProperty("PistasLibres");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setInt(1, esInterior ? 1 : 0);
            ps.setInt(2, numJugadores);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String nombrePista = rs.getString("NOMBRE_PISTA");
                int maxJugadores = rs.getInt("max_jugadores");
                String tamaño = rs.getString("tamaño");

                System.out.println("-> " + nombrePista + " (Tamaño: " + tamaño + ", max jugadores: " + maxJugadores + ")");
                pistasEncontradas = true;
            }
            
            if (!pistasEncontradas) {
                System.out.println("No se encontraron pistas disponibles con los criterios especificados.");
            }
            
            rs.close();
            ps.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		connection.closeConnection();
    }

}
