package es.uco.pw.display;

import java.util.ArrayList;
import java.util.Scanner;

import es.uco.pw.business.material.MaterialDTO;
import es.uco.pw.business.pista.PistaDTO;
import es.uco.pw.business.pista.tamanopista;
import es.uco.pw.data.dao.PistaDAO;

/**
 * Clase principal que gestiona el menú de opciones para agregar, listar y buscar pistas.
 * El menú ofrece las opciones de agregar una nueva pista, listar las pistas no disponibles
 * y buscar pistas libres en función del número de jugadores y el tipo de pista (interior/exterior).
 */
public class mainpistas
{
	/**
     * Método principal que gestiona el menú de opciones para interactuar con el sistema de pistas.
     * Ofrece un menú interactivo donde el usuario puede elegir entre agregar una nueva pista,
     * listar las pistas no disponibles o buscar pistas libres según el número de jugadores y el tipo.
     * 
     * @param args Argumentos de línea de comandos (no se utilizan en este caso).
     */
	public static void main(String[] args)
	{
		PistaDAO pistaDAO = new PistaDAO();
				
		Scanner scanner = new Scanner(System.in);
		int opcion = 0;

		do
		{
			System.out.println("----- Menú Gestor de Pistas -----");
			System.out.println("1) Agregar una nueva pista");
			System.out.println("2) Listar pistas no disponibles");
			System.out.println("3) Buscar pistas libres según número de jugadores y tipo");
			System.out.println("4) Salir");
			opcion = scanner.nextInt();
			
			if (opcion == 1)
			{
					agregarNuevaPista(pistaDAO, scanner);
			}
			else if (opcion == 2)
			{
					pistaDAO.listarPistasNoDisponibles();
			}
			else if (opcion == 3)
			{
					buscarLibres(pistaDAO, scanner);
			}
			else if (opcion == 4)
			{
					mainprincipal.main(args);
					break;
			}
			else
			{
					System.out.println("Opción no válida.");
			}
			
		} while (opcion != 4);

		scanner.close();
	}

	/**
     * Método que permite agregar una nueva pista al sistema. Recibe la información de la pista
     * desde el usuario, incluyendo nombre, disponibilidad, tipo de pista, tamaño y materiales asociados.
     * 
     * @param pistaDAO Instancia de PistaDAO utilizada para interactuar con la base de datos.
     * @param scanner Instancia de Scanner para leer la entrada del usuario.
     */
	private static void agregarNuevaPista(PistaDAO pistaDAO, Scanner scanner)
	{
		scanner.nextLine();
		
		System.out.print("Introduce el nombre de la pista: ");
		String nombre = scanner.nextLine();
		
		System.out.print("¿Está disponible? (true/false): ");
		boolean disponible = scanner.nextBoolean();
		
		System.out.print("¿Es interior? (true/false): ");
		boolean esInterior = scanner.nextBoolean();
		
		System.out.print("Introduce el tamaño de pista (minibasket, adultos, tres_vs_tres, none): ");
		tamanopista tamano = tamanopista.valueOf(scanner.next().toLowerCase());
		
		System.out.print("Introduce el número máximo de jugadores: ");
		int maxJugadores = scanner.nextInt();
		
		pistaDAO.listarMateriales();		
		System.out.print("Introduce el número de los materiales que quiera asociar (introduce 0 para terminar): ");
		int OpcionMaterial;
		ArrayList<MaterialDTO> materialesSeleccionados = new ArrayList<>();
		do
		{
			OpcionMaterial = scanner.nextInt();
			if(OpcionMaterial != 0)
			{
				MaterialDTO materialSeleccionado = pistaDAO.buscarMaterialPorId(OpcionMaterial);
	            
	            if(materialSeleccionado != null)
	            {
	                    materialesSeleccionados.add(materialSeleccionado);
	            }
	            else
	            {
	                System.out.println("Error: Material no encontrado.");
	            }
			}
		} while (OpcionMaterial != 0);
		
			PistaDTO nuevaPista = new PistaDTO(nombre, disponible, esInterior, tamano, maxJugadores);
			for(MaterialDTO material : materialesSeleccionados)
			{
		        nuevaPista.asociarMaterial_Pista(material);
		    }
			if(pistaDAO.addPista(nuevaPista))
			{
				System.out.println("Pista agregada exitosamente.");
			}
			else
			{
				System.out.println("Error: La pista no ha sido agregada.");
			}
	}

	/**
     * Método que permite buscar pistas libres según el número de jugadores y el tipo de pista (interior o exterior).
     * Solicita al usuario la cantidad de jugadores y el tipo de pista, y luego consulta la base de datos para encontrar
     * las pistas disponibles que cumplan con esos requisitos.
     * 
     * @param pistaDAO Instancia de PistaDAO utilizada para interactuar con la base de datos.
     * @param scanner Instancia de Scanner para leer la entrada del usuario.
     */
	private static void buscarLibres(PistaDAO pistaDAO, Scanner scanner)
	{
		System.out.print("Ingrese el número de jugadores: ");
		int numJugadores = scanner.nextInt();
		
		System.out.print("¿Es interior? (true/false): ");
		boolean esInterior = scanner.nextBoolean();
		
		pistaDAO.buscarPistasLibres(numJugadores, esInterior);
	}

}