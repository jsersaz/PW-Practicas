package es.uco.pw.business.reserva;

import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import es.uco.pw.business.jugador.JugadorDTO;
import es.uco.pw.business.material.Estado;
import es.uco.pw.business.material.MaterialDTO;
import es.uco.pw.business.material.Tipo;
import es.uco.pw.business.pista.PistaDTO;
import es.uco.pw.business.pista.tamanopista;
import es.uco.pw.business.reserva.BonoDTO;
import es.uco.pw.business.reserva.ReservaDTO;
import es.uco.pw.business.reserva.ReservaInfantilDTO;
import es.uco.pw.business.reserva.ReservaFamiliarDTO;
import es.uco.pw.business.reserva.ReservaIndividualDTO;
import es.uco.pw.business.reserva.ReservaAdultosDTO;
import es.uco.pw.business.reserva.ReservaBonoDTO;
import es.uco.pw.business.reserva.ReservaFactoryDTO;
import es.uco.pw.data.dao.BonoDAO;
import es.uco.pw.data.dao.ReservaDAO;
import es.uco.pw.data.dao.JugadorDAO;
import es.uco.pw.data.dao.PistaDAO;

/**
 * Clase que gestiona las reservas de pistas deportivas y bonos asociados.
 */
public class gestordereservas {
    private static gestordereservas gestor; // Instancia única del gestor

    /**
     * Constructor privado para inicializar las listas de reservas y bonos,
     * así como cargar las propiedades desde un archivo.
     */
    private gestordereservas() {

    }

    /**
     * Método para obtener la instancia única del gestor de reservas.
     *
     * @return la instancia del gestor
     */
    public static gestordereservas getGestor() {
        if (gestor == null) {
            gestor = new gestordereservas();
        }
        return gestor;
    }

    /**
     * Método para validar las condiciones generales de la reserva.
     *
     * @param pista  la pista a reservar
     * @param fecha  la fecha de la reserva
     * @return true si las condiciones son válidas, false en caso contrario
     */
    private boolean validarCondicionesReserva(PistaDTO pista, LocalDate fecha) {
        LocalDate ahora = LocalDate.now();
        if (fecha.isBefore(ahora.plusDays(1))) {
            // System.out.println("La reserva debe hacerse con al menos 24 horas de antelación.");
            return false;
        }
        // Validar disponibilidad de la pista
        if (pista.isEstado() == false) {
            // System.out.println("La pista no está disponible en la fecha seleccionada.");
            return false;
        }
        return true;
    }

    /**
     * Método para calcular el precio de la reserva según la duración.
     *
     * @param duracion la duración de la reserva en minutos
     * @return el precio correspondiente a la duración
     * @throws IllegalArgumentException si la duración no es válida
     */
    public float calcularPrecio(int duracion) {
        switch (duracion) {
            case 60:
                return 20f;
            case 90:
                return 30f;
            case 120:
                return 40f;
            default:
                throw new IllegalArgumentException("Duración no válida. Debe ser 60, 90 o 120 minutos.");
        }
    }

    /**
     * Método para hacer una reserva individual.
     * 
     * Este método valida las condiciones de la reserva, calcula el precio de la reserva aplicando
     * un descuento del 10% si corresponde, y crea una reserva según el tipo especificado (infantil,
     * familiar o adultos) utilizando el patrón de diseño de fábrica. Si la reserva es exitosa, se añade.
     *
     * @param bono           el bono asociado a la reserva
     * @param jugador        el jugador que realiza la reserva
     * @param pista          la pista a reservar
     * @param fecha          la fecha de la reserva
     * @param duracion       la duración de la reserva en minutos
     * @param tipoReserva    el tipo de reserva (infantil, familiar, adultos)
     * @param numeroNinos    el número de niños en la reserva
     * @param numeroAdultos  el número de adultos en la reserva
     * @return true si la reserva fue exitosa, false en caso contrario
     */
    public boolean hacerReservaIndividual(BonoDTO bono, JugadorDTO jugador, PistaDTO pista, LocalDate fecha, int duracion, String tipoReserva, int numeroNinos, int numeroAdultos) {
        ReservaDAO reservaDAO = new ReservaDAO();
    	
    	if (!validarCondicionesReserva(pista, fecha)) {
            return false;
        }

        float precio = calcularPrecio(duracion);
        float descuento;
        if (jugador.calcularAntiguedad() > 2) {
        	descuento = precio * 0.1f;
        }
        else {descuento = 0.0f;}
        ReservaFactoryDTO reservaIndividualFactory = new ReservaIndividualDTO();
        String idReserva;

        switch (tipoReserva.toLowerCase()) {
            case "infantil":
                idReserva = jugador.getDni() + "-I-I-" + fecha;
                ReservaInfantilDTO reservaInfantil = reservaIndividualFactory.crearReservaInfantil(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroNinos);
                reservaDAO.insertarReservaInfantil(reservaInfantil);
                break;
            case "familiar":
                idReserva = jugador.getDni() + "-F-I-" + fecha;
                ReservaFamiliarDTO reservaFamiliar = reservaIndividualFactory.crearReservaFamiliar(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroNinos, numeroAdultos);
                reservaDAO.insertarReservaFamiliar(reservaFamiliar);
                break;
            case "adultos":
                idReserva = jugador.getDni() + "-A-I-" + fecha;
                ReservaAdultosDTO reservaAdultos = reservaIndividualFactory.crearReservaAdultos(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroAdultos);
                reservaDAO.insertarReservaAdultos(reservaAdultos);
                break;
            default:
                // System.out.println("Error. Tipo de reserva no válido.");
                return false;
        }
        return true;
    }

    
	/**
	 * Método para hacer una reserva dentro de un bono.
	 *
	 * Este método valida las condiciones de la reserva, verifica si el bono es válido,
	 * calcula el precio de la reserva aplicando un descuento del 5%, y crea una reserva
	 * según el tipo especificado (infantil, familiar o adultos) utilizando el patrón de diseño
	 * de fábrica. Si la reserva es exitosa, se añade.
	 *
	 * @param bono      El bono utilizado para la reserva.
	 * @param jugador   El jugador que realiza la reserva.
	 * @param pista     La pista en la que se realizará la reserva.
	 * @param fecha     La fecha de la reserva.
	 * @param duracion  La duración de la reserva en minutos.
	 * @param tipoReserva El tipo de reserva a realizar (infantil, familiar o adultos).
	 * @return true si la reserva se realiza correctamente, false en caso contrario.
	 */
	public boolean hacerReservaBono(BonoDTO bono, JugadorDTO jugador, PistaDTO pista, LocalDate fecha, int duracion, String tipoReserva, int numeroNinos, int numeroAdultos) {
		ReservaDAO reservaDAO = new ReservaDAO();
		
		if(!validarCondicionesReserva(pista, fecha)) {
	        return false;
	    }
	
	    if(!bono.esValido()) {
	        // System.out.println("Error. El bono con ID " + bono.getIdBono() + " ha caducado.");
	        return false;
	    }
	
	    float precio = calcularPrecio(duracion);
	    float descuento = precio * 0.05f;
	    ReservaFactoryDTO reservaBonoFactory = new ReservaBonoDTO();
	    String idReserva;
	    switch (tipoReserva.toLowerCase()) {
	        case "infantil":
	            idReserva = jugador.getDni() + "-I-B-" + fecha;
	            ReservaInfantilDTO reservaInfantil = reservaBonoFactory.crearReservaInfantil(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroNinos);
	            reservaDAO.insertarReservaInfantil(reservaInfantil);
	            break;
	        case "familiar":
	            idReserva = jugador.getDni() + "-F-B-" + fecha;
	            ReservaFamiliarDTO reservaFamiliar = reservaBonoFactory.crearReservaFamiliar(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroNinos, numeroAdultos);
	            reservaDAO.insertarReservaFamiliar(reservaFamiliar);
	            break;
	        case "adultos":
	            idReserva = jugador.getDni() + "-A-B-" + fecha;
	            ReservaAdultosDTO reservaAdultos = reservaBonoFactory.crearReservaAdultos(bono, idReserva, jugador.getDni(), fecha, duracion, pista.getNombre(), precio, descuento, numeroAdultos);
	            reservaDAO.insertarReservaAdultos(reservaAdultos);
	            break;
	        default:
	            // System.out.println("Error. Tipo de reserva no válido.");
	            return false;
	    }
	    return true;
	}


	/**
	 * Método para crear un bono.
	 *
	 * Este método crea una nueva instancia de un bono y lo añade.
	 *
	 * @param idBono          El identificador del bono.
	 * @param fechaCreacion   La fecha de creación del bono.
	 * @param tipoPista      El tipo de pista asociado al bono.
	 * @return true si el bono se crea correctamente, false en caso contrario.
	 */
	public boolean crearBono(String idBono, String idUsuario, LocalDate fechaCreacion, tamanopista tipoPista) {
		BonoDAO bonoDAO = new BonoDAO();
		
	    BonoDTO bono = new BonoDTO(idBono, idUsuario, fechaCreacion, tipoPista);
	    
	    bonoDAO.insertarBono(bono);
	    return true;
	}


	/**
	 * Método para cancelar una reserva.
	 *
	 * Este método verifica si la reserva puede ser cancelada según su fecha y el
	 * identificador del usuario. Si la cancelación es válida, se elimina la reserva.
	 *
	 * @param reserva  La reserva a cancelar.
	 * @param dni      El DNI del usuario que intenta cancelar la reserva.
	 * @return true si la reserva se cancela correctamente, false en caso contrario.
	 */
	public boolean cancelarReserva(ReservaDTO reserva, String dni) {
		ReservaDAO reservaDAO = new ReservaDAO();
		BonoDAO bonoDAO = new BonoDAO();
		
	    LocalDate ahora = LocalDate.now();
	    if (reserva.getFecha().isBefore(ahora.plusDays(1))) {
	        // System.out.println("No se puede cancelar una reserva en las últimas 24 horas.");
	        return false;
	    }
	    if (reserva.getIdUsuario().equals(dni)) {
	        String[] partes = reserva.getIdReserva().split("-");
	        if(partes[1].equals("I")) {
	        	reservaDAO.borrarInfantil(reserva);
	        }
	        else if(partes[1].equals("F")) {
	        	reservaDAO.borrarFamiliar(reserva);
	        }
	        else if(partes[1].equals("A")) {
	        	reservaDAO.borrarAdulto(reserva);
	        }
	        
	        reservaDAO.borrarReserva(reserva);
	        
	        BonoDTO bonoBorrar = obtenerBono(reserva.idUsuario, reserva.getIdBono());
	        int newNS = bonoBorrar.getNumeroSesion() - 2;
	        bonoBorrar.setNumeroSesion(newNS);
	        bonoDAO.actualizarBono(bonoBorrar);
	        return true;
	    }
	    else {
	        // System.out.println("No pueden cancelar reservas de otros usuarios.");
	        return false;
	    }
	}


	/**
	 * Método para consultar el número de reservas futuras.
	 *
	 * Este método cuenta cuántas reservas están programadas para después de la fecha actual.
	 *
	 * @return El número de reservas futuras.
	 */
	public int consultarReservasFuturas() {
		ReservaDAO reservaDAO = new ReservaDAO();
		int reservasFuturas = reservaDAO.reservasFuturas();
		return reservasFuturas;
	}


	/**
     * Método para obtener las reservas por día y pista.
     *
     * @param fecha   la fecha de las reservas
     * @param idPista el identificador de la pista
     */
	public void ReservasDiaYPista(LocalDate fecha, String idPista) {
		ReservaDAO reservaDAO = new ReservaDAO();
		reservaDAO.reservasDiaYPista(fecha, idPista);
	}


	/**
     * Método para obtener una reserva por su identificador.
     *
     * @param idReserva el identificador de la reserva
     * @return un objeto ReservaDTO correspondiente al identificador
     */
	public ReservaDTO obtenerReserva(String idReserva) {
		ReservaDTO reservaE = new ReservaDTO();
		ReservaDAO reservaDAO = new ReservaDAO();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		Map<String, Object> resultado = reservaDAO.obtenerReserva(idReserva);
		
		String ID_RESERVA = (String) resultado.get("ID_RESERVA");
		String id_usuario = (String) resultado.get("id_usuario");
		LocalDate fecha = LocalDate.parse((String) resultado.get("fecha"), formatter);
		int duracion = Integer.parseInt((String) resultado.get("duración"));
		String id_pista = (String) resultado.get("id_pista");
		float precio = Float.parseFloat((String) resultado.get("precio"));
		float descuento = Float.parseFloat((String) resultado.get("descuento"));
		String Id_bono = (String) resultado.get("Id_bono");
		int numero_sesion = Integer.parseInt((String) resultado.get("numero_sesion"));
		
	    reservaE = new ReservaDTO(ID_RESERVA, id_usuario, fecha, duracion, id_pista, precio, descuento, Id_bono, numero_sesion);
	    
	    return reservaE;
	}


	/**
	 * Busca un jugador existente por su DNI.
	 * @param dni El DNI del jugador a buscar.
	 * @return jugadorE El jugador correspondiente al DNI. Devuelve un jugador vacío si no se encuentra.
	 */
	public JugadorDTO obtenerUsuario(String dni) {
		JugadorDTO jugadorE = new JugadorDTO();
		JugadorDAO jugadorDAO = new JugadorDAO();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		Map<String, Object> resultado = jugadorDAO.obtenerJugador(dni);
		
		String nombre = (String) resultado.get("nombre");
		String apellidos = (String) resultado.get("apellidos");
		LocalDate fecha_nacimiento = LocalDate.parse((String) resultado.get("fecha_nacimiento"), formatter);
		LocalDate fecha_inscripcion = LocalDate.parse( (String) resultado.get("fecha_inscripcion"), formatter);
		String email = (String) resultado.get("email");
		String DNI = (String) resultado.get("DNI");
		
	    jugadorE = new JugadorDTO(nombre, apellidos, fecha_nacimiento, fecha_inscripcion, email, DNI);
	    
	    return jugadorE;
	}


	/**
     * Método para obtener una pista por su nombre.
     *
     * @param nombre el nombre de la pista
     * @return un objeto PistaDTO correspondiente al nombre, o una pista vacía si no se encuentra
     */
	public PistaDTO obtenerPista(String nombre) {
		PistaDTO pistaE = new PistaDTO();
		PistaDAO pistaDAO = new PistaDAO();
		
		Map<String, Object> resultado = pistaDAO.obtenerPista(nombre);
		
		String NOMBRE_PISTA = (String) resultado.get("NOMBRE_PISTA");
		
		Boolean estado = true;
		int estadoInt = Integer.parseInt((String) resultado.get("estado"));
		if(estadoInt == 0) {
			estado = false;
		}
		else if(estadoInt == 1) {
			estado = true;
		}
		
		Boolean tipo_interior = true;;
		int tipo_interiorInt = Integer.parseInt((String) resultado.get("tipo_interior"));
		if(tipo_interiorInt == 0) {
			tipo_interior = false;
		}
		else if(tipo_interiorInt == 1) {
			tipo_interior = true;
		}
		
		tamanopista tamano = tamanopista.valueOf((String) resultado.get("tamaño"));
		int max_jugadores = Integer.parseInt((String) resultado.get("max_jugadores"));
		
	    pistaE = new PistaDTO(NOMBRE_PISTA, estado, tipo_interior, tamano, max_jugadores);
	
	    return pistaE;
	}



	/**
     * Método para obtener un bono por su identificador.
     *
     * @param idUsuario el identificador del usuario asociado al bono
     * @param idBono    el identificador del bono
     * @return un objeto BonoDTO correspondiente al bono, o null si no existe
     */
	public BonoDTO obtenerBono(String idUsuario, String idBono) {
		BonoDTO bonoE = new BonoDTO();
		BonoDAO bonoDAO = new BonoDAO();
	
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		Map<String, Object> resultado = bonoDAO.obtenerBono(idBono);
		
		String ID_BONO = (String) resultado.get("ID_BONO");
		int numero_sesion = Integer.parseInt((String) resultado.get("numero_sesión"));
		numero_sesion++;
		LocalDate fecha_caducidad = LocalDate.parse((String) resultado.get("fecha_caducidad"), formatter);
		LocalDate fecha_creacion = LocalDate.parse( (String) resultado.get("fecha_creación"), formatter);
		tamanopista tipo_pista = tamanopista.valueOf((String) resultado.get("tipo_pista"));
		
		bonoE = new BonoDTO(ID_BONO, idUsuario, numero_sesion, fecha_creacion, fecha_caducidad, tipo_pista);
	
		bonoDAO.actualizarBono(bonoE);
	
		return bonoE;
	}

}