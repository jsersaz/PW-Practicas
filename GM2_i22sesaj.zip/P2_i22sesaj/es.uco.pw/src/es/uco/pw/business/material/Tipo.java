package es.uco.pw.business.material;

public enum Tipo {
	pelotas, 
	canastas,
	conos,
	none
}
