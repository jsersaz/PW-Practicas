
Para ejecutar nuestro trabajo, tiene que abrir eclipse y ejecutar el mainprincipal en la opción de ejecutar programa