package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.data.common.DBConnection;


/**
 * Clase encargada de interactuar con la base de datos para gestionar la información
 * relacionada con las pistas.
 * Esta clase permite obtener los detalles de una pista a partir de su nombre.
 */
public class PistaDAO {
	private Connection con;
	private Properties prop;
	
	
	/**
     * Constructor que carga las propiedades de configuración necesarias para
     * interactuar con la base de datos.
     */
	public PistaDAO()
	{
		prop= new Properties(); 
		try (FileInputStream input = new FileInputStream("sql.properties")) {
			prop.load(input);
		} catch (IOException e) {e.printStackTrace();}	   
	}
	
	
	/**
     * Obtiene los detalles de una pista desde la base de datos utilizando su nombre.
     * 
     * @param nombre El nombre de la pista a obtener.
     * @return Un mapa con los detalles de la pista, como tipo (interior o exterior),
     *         estado, tamaño y el número máximo de jugadores.
     */
	public Map<String, Object> obtenerPista(String nombre){
		Map<String, Object> result = null;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("getPista");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nombre);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				result = new HashMap<>();
				result.put("NOMBRE_PISTA", nombre);
				result.put("tipo_interior", rs.getString("tipo_interior"));
				result.put("estado", rs.getString("estado"));
				result.put("tamaño", rs.getString("tamaño"));
				result.put("max_jugadores", rs.getString("max_jugadores"));
			}
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return result;
	}
}
