package es.uco.pw.business.material;

public enum Estado {
	disponible,
	reservado,
	mal_estado,
	none
}
