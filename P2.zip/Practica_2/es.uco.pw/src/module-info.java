/**
 * 
 */
/**
 * 
 */
module es.uco.pw {
	requires java.sql;
	requires mysql.connector;
}