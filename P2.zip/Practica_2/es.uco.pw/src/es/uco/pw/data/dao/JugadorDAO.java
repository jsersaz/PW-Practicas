package es.uco.pw.data.dao;

public class JugadorDAO {

}
