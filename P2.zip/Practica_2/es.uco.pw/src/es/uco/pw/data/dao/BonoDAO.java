package es.uco.pw.data.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.Properties;

import com.mysql.jdbc.Connection;

import es.uco.pw.business.reserva.BonoDTO;
import es.uco.pw.data.common.DBConnection;

public class BonoDAO {
	private Connection con;
	private Properties prop;
	
	public BonoDAO()
	{
		prop= new Properties(); 
		try (FileInputStream input = new FileInputStream("sql.properties")) {
			prop.load(input);
		} catch (IOException e) {e.printStackTrace();}	   
	}
	
	public int insertarBono(BonoDTO bono) {
		int status = 0;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("addBono");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, bono.getIdBono());
			ps.setInt(2, bono.getNumeroSesion());
			ps.setDate(3, Date.valueOf(bono.getFechaCaducidad()));
			ps.setDate(4, Date.valueOf(bono.getFechaCreacion()));
			
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return status;
	}
	
	public int actualizarBono(BonoDTO bono) {
		int status = 0;
		DBConnection connection = new DBConnection();
		String sql;
		
		try {
			sql = prop.getProperty("updateBono");
			con = (Connection) connection.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setInt(1, bono.getNumeroSesion());
			ps.setString(2, bono.getIdBono());
			
			status = ps.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		
		connection.closeConnection();
		return status;
	}
}
